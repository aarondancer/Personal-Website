//Preloader
$(window).load(function() {
	$("#intro-loader").delay(500).fadeOut();
	$(".mask").delay(500).fadeOut("slow");
});

$(document).ready(function() {

  //initializeMap(lat,lng);
  
	//Elements Appear from top
	$('.item_top').each(function() {
		$(this).appear(function() {
			$(this).delay(0).animate({
				opacity : 1,
				top : "0px"
			}, 500);
		});
	});

	//Elements Appear from bottom
	$('.item_bottom').each(function() {
		$(this).appear(function() {
			$(this).delay(0).animate({
				opacity : 1,
				bottom : "0px"
			}, 500);
		});
	});
	//Elements Appear from left
	$('.item_left').each(function() {
		$(this).appear(function() {
			$(this).delay(0).animate({
				opacity : 1,
				left : "0px"
			}, 500);
		});
	});
	
	//Elements Appear from right
	$('.item_right').each(function() {
		$(this).appear(function() {
			$(this).delay(0).animate({
				opacity : 1,
				right : "0px"
			}, 500);
		});
	});
	
	//Elements Appear in fadeIn effect
	$('.item_fade_in').each(function() {
		$(this).appear(function() {
			$(this).delay(250).animate({
				opacity : 1,
				right : "0px"
			}, 1500);
		});
	});

	$("#nav").sticky({
		topSpacing : 0
	});

  rotate('rotate1');

	// Contact Form Request
  $(".validate").validate();	
  var form = $('#contactform');
	var submit = $('#contactForm_submit');	
	var alert = $('.form-respond'); 

  	// form submit event
    $(document).on('submit', '#contactform', function(e) {
		e.preventDefault(); // prevent default form submit
		// sending ajax request through jQuery
		$.ajax({
			url: 'sendemail.php', 
			type: 'POST', 
			dataType: 'html',
			data: form.serialize(), 
			beforeSend: function() {
				alert.fadeOut();
				submit.html('Sending....'); // change submit button text
			},
			success: function(data) {
				form.fadeOut(300);
        alert.html(data).fadeIn(500); // fade in response data     
			},
			error: function(e) {
				console.log(e)
			}
		});
	});


	//Navigation Dropdown
	$('.nav a.collapse-menu').click(function() {
		$(".navbar-collapse").collapse("hide")
	});

	$('body').on('touchstart.dropdown', '.dropdown-menu', function(e) {
		e.stopPropagation();
	});

	var onMobile = false;
	if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
		onMobile = true;
	}

	//Back To Top
	$(window).scroll(function() {
		if ($(window).scrollTop() > 400) {
			$("#back-top").fadeIn(0);
		} else {
			$("#back-top").fadeOut(0);
		}
	});
	$('#back-top').click(function() {
		$('html, body').stop().animate({
			scrollTop : 0
		}, 1500, 'easeInOutExpo');
	});

	if ((onMobile === false ) && ($('.parallax-slider').length )) {
		skrollr.init({
			edgeStrategy : 'set',
			smoothScrolling : false,
			forceHeight : false
		});

	}
});

//Navigation Scrolling
	$(function() {
		if( screen.width <= 480 ) {

			$('.nav li a').bind('click', function(event) {
				var $anchor = $(this);

				$('html, body').stop().animate({
					scrollTop : $($anchor.attr('href')).offset().top - 70
				}, 500, 'easeInOutExpo');

				event.preventDefault();
			});
			}
	});
   
//FullScreen Slider
$(function(){
$('#fullscreen-slider').maximage({
cycleOptions: {
fx: 'fade',
speed: 500,
timeout: 5000,
pause: 1
},
onFirstImageLoaded: function(){
jQuery('#cycle-loader').hide();
jQuery('#fullscreen-slider').fadeIn('slow');
},
// cssBackgroundSize might be causing choppiness in retina display safari
cssBackgroundSize: false
});
});

//Parallax
$(window).bind('load', function() {
	parallaxInit();
});

function parallaxInit() {
	$('#one-parallax').parallax("50%", 0.2);
	$('#two-parallax').parallax("50%", 0.2);
	$('#three-parallax').parallax("50%", 0.2);
	/*add as necessary*/
}

// // Number Counter
// (function() {
// 	var Core = {
// 		initialized : false,
// 		initialize : function() {
// 			if (this.initialized)
// 				return;
// 			this.initialized = true;
// 			this.build();
// 		},
// 		build : function() {
// 			this.animations();
// 		},
// 		animations : function() {
// 			// Count To
// 			$(".number-counters [data-to]").each(function() {
// 				var $this = $(this);
// 				$this.appear(function() {
// 					$this.countTo({});
// 				}, {
// 					accX : 0,
// 					accY : -150
// 				});
// 			});
// 		},
// 	};
// 	Core.initialize();
// })();

// //Initilize Google Map
//  function initializeMap(lat,lng) {
//      var mapOptions = {
//        center: new google.maps.LatLng(lat, lng),
//        zoom: 16,
//        mapTypeId: google.maps.MapTypeId.ROADMAP
//      };
//      var map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions);
//      var marker = new google.maps.Marker({
//      position: mapOptions['center'],
//      map: map,
//      }); 
//      return map;
//  }    
